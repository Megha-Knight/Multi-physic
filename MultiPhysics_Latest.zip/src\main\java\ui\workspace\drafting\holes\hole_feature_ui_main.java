package ui.workspace.drafting.holes;

import java.util.Locale;
import java.util.UUID;
import ui.workspace.drafting.faces.face_kind_ui_main;
import ui.workspace.drafting.topology.boundary_relationship_ui_main;
import ui.workspace.drafting.topology.edge_machining_analyzer_ui_main;

/**
 * hole_feature_ui_main.java
 * Parametric Hole Feature model for solid CAD bodies with topology boundary awareness.
 */
public class hole_feature_ui_main {

    public enum HoleType {
        SIMPLE("Simple Hole"), COUNTERSINK("Countersink Hole"), COUNTERBORE("Counterbore Hole");
        private final String label;
        HoleType(String label) { this.label = label; }
        public String getLabel() { return label; }
    }

    public enum CutoutShape {
        CIRCLE("Circle"), SQUARE("Square"), RECTANGLE("Rectangle"),
        EQUILATERAL_TRIANGLE("Equilateral Triangle"), RIGHT_TRIANGLE("Right Triangle");
        private final String label;
        CutoutShape(String label) { this.label = label; }
        public String getLabel() { return label; }
    }

    private final String id, ownerShapeId;
    private final HoleType holeType;
    private final face_kind_ui_main faceKind;
    private double u, v, diameter, depth, csDiameter, csAngle = 90.0, cbDiameter, cbDepth, width2 = 0.0;
    private boolean throughAll, visible = true;
    private CutoutShape cutoutShape = CutoutShape.CIRCLE;
    private String name, diagnosticMessage = null;
    private ui.workspace.drafting.features.feature_state_ui_main state = ui.workspace.drafting.features.feature_state_ui_main.CLEAN;
    private boundary_relationship_ui_main boundaryRelationship = null;

    public hole_feature_ui_main(String id, String ownerShapeId, face_kind_ui_main faceKind, double u, double v, double diameter, double depth, boolean throughAll) {
        this(id, ownerShapeId, null, HoleType.SIMPLE, faceKind, u, v, diameter, depth, throughAll, 0, 90.0, 0, 0, CutoutShape.CIRCLE, 0.0);
    }

    public hole_feature_ui_main(String id, String ownerShapeId, HoleType holeType, face_kind_ui_main faceKind, double u, double v, double diameter, double depth, boolean throughAll) {
        this(id, ownerShapeId, null, holeType, faceKind, u, v, diameter, depth, throughAll, 0, 90.0, 0, 0, CutoutShape.CIRCLE, 0.0);
    }

    public hole_feature_ui_main(String id, String ownerShapeId, HoleType holeType, face_kind_ui_main faceKind, double u, double v, double diameter, double depth, boolean throughAll, double csDiameter, double csAngle, double cbDiameter, double cbDepth) {
        this(id, ownerShapeId, null, holeType, faceKind, u, v, diameter, depth, throughAll, csDiameter, csAngle, cbDiameter, cbDepth, CutoutShape.CIRCLE, 0.0);
    }

    public hole_feature_ui_main(String id, String ownerShapeId, HoleType holeType, face_kind_ui_main faceKind, double u, double v, double diameter, double depth, boolean throughAll, double csDiameter, double csAngle, double cbDiameter, double cbDepth, CutoutShape cutoutShape, double width2) {
        this(id, ownerShapeId, null, holeType, faceKind, u, v, diameter, depth, throughAll, csDiameter, csAngle, cbDiameter, cbDepth, cutoutShape, width2);
    }

    public hole_feature_ui_main(String id, String ownerShapeId, String name, HoleType holeType, face_kind_ui_main faceKind,
                                double u, double v, double diameter, double depth, boolean throughAll,
                                double csDiameter, double csAngle, double cbDiameter, double cbDepth,
                                CutoutShape cutoutShape, double width2) {
        this.id = (id != null && !id.isBlank()) ? id : UUID.randomUUID().toString();
        this.ownerShapeId = ownerShapeId;
        this.name = name;
        this.holeType = (holeType != null) ? holeType : HoleType.SIMPLE;
        this.faceKind = (faceKind != null) ? faceKind : face_kind_ui_main.TOP;
        this.u = u; this.v = v; this.diameter = diameter; this.depth = depth; this.throughAll = throughAll;
        this.csDiameter = csDiameter; this.csAngle = csAngle; this.cbDiameter = cbDiameter; this.cbDepth = cbDepth;
        this.cutoutShape = (cutoutShape != null) ? cutoutShape : CutoutShape.CIRCLE;
        this.width2 = width2;
    }

    public String getId() { return id; }
    public String getOwnerShapeId() { return ownerShapeId; }
    public String getName() { return (name != null && !name.isBlank()) ? name : getDefaultName(); }
    public void setName(String name) { this.name = name; }
    public HoleType getHoleType() { return holeType; }
    public face_kind_ui_main getFaceKind() { return faceKind; }
    public String getFaceId() { return (ownerShapeId != null && faceKind != null) ? ownerShapeId + ":" + faceKind.name() : ""; }
    public String getTopologyFaceId() { return (ownerShapeId != null && faceKind != null) ? ownerShapeId + ":F:" + faceKind.name() : ""; }

    public ui.workspace.drafting.features.feature_state_ui_main getState() { return state; }
    public void setState(ui.workspace.drafting.features.feature_state_ui_main s) { this.state = (s != null) ? s : ui.workspace.drafting.features.feature_state_ui_main.CLEAN; }
    public String getDiagnosticMessage() { return diagnosticMessage; }
    public void setDiagnosticMessage(String msg) { this.diagnosticMessage = msg; }
    public boolean isVisible() { return visible; }
    public void setVisible(boolean v) { this.visible = v; }
    public boundary_relationship_ui_main getBoundaryRelationship() { return boundaryRelationship; }
    public void setBoundaryRelationship(boundary_relationship_ui_main rel) { this.boundaryRelationship = rel; }

    public double getU() { return u; } public void setU(double u) { this.u = u; }
    public double getV() { return v; } public void setV(double v) { this.v = v; }
    public double getDiameter() { return diameter; } public void setDiameter(double d) { this.diameter = d; }
    public double getRadius() { return Math.max(0.05, diameter * 0.5); }
    public double getDepth() { return depth; } public void setDepth(double d) { this.depth = d; }
    public boolean isThroughAll() { return throughAll; } public void setThroughAll(boolean b) { this.throughAll = b; }
    public double getCsDiameter() { return csDiameter; } public void setCsDiameter(double d) { this.csDiameter = d; }
    public double getCsAngle() { return csAngle; } public void setCsAngle(double a) { this.csAngle = a; }
    public double getCbDiameter() { return cbDiameter; } public void setCbDiameter(double d) { this.cbDiameter = d; }
    public double getCbDepth() { return cbDepth; } public void setCbDepth(double d) { this.cbDepth = d; }

    public boolean revalidate(ui.workspace.drafting.shape_item_ui_main host) {
        if (host == null || !host.getId().equals(ownerShapeId)) {
            state = ui.workspace.drafting.features.feature_state_ui_main.INVALID;
            diagnosticMessage = "Host body not found";
            boundaryRelationship = null;
            return false;
        }
        boundaryRelationship = edge_machining_analyzer_ui_main.analyzeHole(host, host.getTopology(), this);
        if (boundaryRelationship != null && !boundaryRelationship.isValid()) {
            state = ui.workspace.drafting.features.feature_state_ui_main.INVALID;
            diagnosticMessage = boundaryRelationship.getDiagnosticMessage();
            return false;
        }
        if (state == ui.workspace.drafting.features.feature_state_ui_main.INVALID) {
            state = ui.workspace.drafting.features.feature_state_ui_main.CLEAN;
            diagnosticMessage = null;
        }
        return true;
    }

    public String getDefaultName() {
        if (cutoutShape != null && cutoutShape != CutoutShape.CIRCLE) {
            return String.format(Locale.US, "%s (%.1f mm)", cutoutShape.getLabel(), diameter);
        }
        return switch (holeType) {
            case COUNTERSINK -> String.format(Locale.US, "Countersink (Ø%.1f)", diameter);
            case COUNTERBORE -> String.format(Locale.US, "Counterbore (Ø%.1f)", diameter);
            default -> String.format(Locale.US, "Hole (Ø%.1f)", diameter);
        };
    }

    public double getConeDepth() {
        if (holeType != HoleType.COUNTERSINK || csAngle <= 0.0 || csAngle >= 180.0) return 0.0;
        double deltaR = (csDiameter - diameter) * 0.5;
        return (deltaR <= 0.0) ? 0.0 : deltaR / Math.tan(Math.toRadians(csAngle * 0.5));
    }

    public double getOuterRadius() {
        return switch (holeType) {
            case COUNTERSINK -> Math.max(0.05, csDiameter * 0.5);
            case COUNTERBORE -> Math.max(0.05, cbDiameter * 0.5);
            default -> getRadius();
        };
    }

    public double getOuterDiameter() { return getOuterRadius() * 2.0; }

    public boolean isValid() {
        if (state == ui.workspace.drafting.features.feature_state_ui_main.INVALID) return false;
        if (diameter < 0.1 || faceKind == null) return false;
        return switch (holeType) {
            case SIMPLE -> (throughAll || depth >= 0.1);
            case COUNTERSINK -> (csDiameter > diameter + 1e-4) && (csAngle > 0.1 && csAngle < 179.9)
                    && (getConeDepth() > 1e-4) && (throughAll || depth > getConeDepth() + 1e-4);
            case COUNTERBORE -> (cbDiameter > diameter + 1e-4) && (cbDepth >= 0.1)
                    && (throughAll || depth > cbDepth + 1e-4);
        };
    }

    public boolean fitsWithinFace(double faceWidth, double faceHeight) {
        if (!isValid() || faceWidth <= 0 || faceHeight <= 0) return false;
        double r = getOuterRadius();
        if (getOuterDiameter() >= Math.min(faceWidth, faceHeight)) return false;
        return (Math.abs(u) + r <= faceWidth * 0.5 + 1e-4) && (Math.abs(v) + r <= faceHeight * 0.5 + 1e-4);
    }

    public boolean fitsWithinCylinderCap(double capRadius) {
        if (!isValid() || capRadius <= 0) return false;
        return (Math.hypot(u, v) + getOuterRadius() <= capRadius + 1e-4);
    }

    public CutoutShape getCutoutShape() { return cutoutShape != null ? cutoutShape : CutoutShape.CIRCLE; }
    public void setCutoutShape(CutoutShape s) { this.cutoutShape = s; }
    public double getWidth2() { return width2; }
    public void setWidth2(double w) { this.width2 = w; }

    @Override
    public String toString() {
        String depthStr = throughAll ? "Through-All" : String.format(Locale.US, "Depth: %.1f mm", depth);
        if (cutoutShape != null && cutoutShape != CutoutShape.CIRCLE) {
            return String.format(Locale.US, "%s Cutout (Size: %.1f mm, %s) on %s", cutoutShape.getLabel(), diameter, depthStr, faceKind.getLabel());
        }
        return switch (holeType) {
            case COUNTERSINK -> String.format(Locale.US, "Countersink (D: %.1f mm, Ds: %.1f mm, %.1f deg, %s) on %s", diameter, csDiameter, csAngle, depthStr, faceKind.getLabel());
            case COUNTERBORE -> String.format(Locale.US, "Counterbore (D: %.1f mm, Db: %.1f mm, Hb: %.1f mm, %s) on %s", diameter, cbDiameter, cbDepth, depthStr, faceKind.getLabel());
            default -> String.format(Locale.US, "Simple Hole (Dia: %.1f mm, %s) on %s", diameter, depthStr, faceKind.getLabel());
        };
    }
}
