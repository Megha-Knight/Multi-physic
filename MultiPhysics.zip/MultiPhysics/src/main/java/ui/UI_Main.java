package ui;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

import ui.ribbonbar.ribbon_ui_main;
import ui.toolbar.tools_ui_main;
import ui.navigationbar.navigation_ui_main;
import ui.breadcrumbbar.breadcrumb_ui_main;
import ui.Directorybar.directory_ui_main;
import ui.footerbar.footer_ui_main;

/**
 * UI_Main.java
 * -----------------------------------------------------------------------------
 * The single GOVERNING view for the primary window.
 *
 * NOTE: The in-window blue "Titlebar" (title_ui_main) has been REMOVED.
 * The window now relies on the DEFAULT OS title bar, which carries the
 * "Multi-physics" title, the app logo/icon, and the native close button
 * (all configured in application.Main).
 *
 * Remaining bars are arranged to match the reference wireframe:
 *
 *   +--------------------------------------------------------------+
 *   |  Ribbonbar                                                   |  <- ribbon (now topmost)
 *   +--------------------------------------------------------------+
 *   |                        Toolbar                               |  <- tools
 *   +----------------+---------------------------------------------+
 *   | Navigationbar  |            Bread Crumb Bar                  |  <- nav + crumb
 *   +----------------+---------------------------------------------+
 *   |                |                                             |
 *   | Directory bar  |             (content area)                  |  <- dir + content
 *   |                |                                             |
 *   +----------------+---------------------------------------------+
 *   |                        Footer bar                            |  <- footer
 *   +--------------------------------------------------------------+
 *
 * UI_Main itself is a BorderPane so it can be dropped straight into a Scene.
 */
public class UI_Main extends BorderPane {

    public UI_Main() {
        // ---- TOP STACK: ribbon + toolbar (title bar removed) ----------------
        VBox topStack = new VBox(
            new ribbon_ui_main(),
            new tools_ui_main()
        );
        setTop(topStack);

        // ---- LEFT COLUMN: navigation on top, directory filling below --------
        directory_ui_main directory = new directory_ui_main();
        VBox.setVgrow(directory, Priority.ALWAYS);
        VBox leftColumn = new VBox(
            new navigation_ui_main(),
            directory
        );

        // ---- RIGHT COLUMN: breadcrumb on top, content filling the rest ------
        Region contentArea = new Region();
        contentArea.setStyle("-fx-background-color: #f0f0f0;");

        BorderPane rightColumn = new BorderPane();
        rightColumn.setTop(new breadcrumb_ui_main());
        rightColumn.setCenter(contentArea);

        // ---- CENTER: left column + right column side by side ----------------
        BorderPane workspace = new BorderPane();
        workspace.setLeft(leftColumn);
        workspace.setCenter(rightColumn);
        setCenter(workspace);

        // ---- BOTTOM: footer -------------------------------------------------
        setBottom(new footer_ui_main());
    }
}
