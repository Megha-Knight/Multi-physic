package ui.navigationbar;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

/**
 * navigation_ui_main.java
 * -----------------------------------------------------------------------------
 * The Navigation bar: the small cyan-outlined box sitting above the Directory
 * bar, at the top-left of the working area. Placeholder for view/navigation
 * switching controls. Class name matches the file name exactly.
 */
public class navigation_ui_main extends StackPane {

    /** Kept in sync with the Directory bar width so the left column aligns. */
    public static final double COLUMN_WIDTH = 260;

    public navigation_ui_main() {
        setAlignment(Pos.CENTER);
        setPadding(new Insets(10));
        setPrefWidth(COLUMN_WIDTH);
        setMinWidth(COLUMN_WIDTH);
        setPrefHeight(44);
        // White fill with a bright cyan border, as in the wireframe.
        setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #29ABE2;" +
            "-fx-border-width: 2;"
        );

        Label label = new Label("Navigationbar");
        label.setStyle("-fx-text-fill: #1a1a1a; -fx-font-size: 15px;");

        getChildren().add(label);
    }
}
