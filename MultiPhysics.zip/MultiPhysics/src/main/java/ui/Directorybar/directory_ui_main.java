package ui.Directorybar;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

import ui.navigationbar.navigation_ui_main;

/**
 * directory_ui_main.java
 * -----------------------------------------------------------------------------
 * The Directory bar: the tall left-hand panel below the Navigation bar.
 * Placeholder for a project / file tree. Its width is kept identical to the
 * Navigation bar so the left column lines up perfectly.
 * Class name matches the file name exactly.
 */
public class directory_ui_main extends StackPane {

    public directory_ui_main() {
        setAlignment(Pos.TOP_CENTER);
        setPadding(new Insets(24, 10, 10, 10));
        setPrefWidth(navigation_ui_main.COLUMN_WIDTH);
        setMinWidth(navigation_ui_main.COLUMN_WIDTH);
        // Soft bluish-grey vertical gradient, as in the wireframe.
        setStyle(
            "-fx-background-color: linear-gradient(to bottom, #e4e9f0, #c4ccd8);" +
            "-fx-border-color: #9AA5B1;" +
            "-fx-border-width: 0 1 0 0;"
        );

        Label label = new Label("Directory bar");
        label.setStyle("-fx-text-fill: #1a1a1a; -fx-font-size: 16px;");

        getChildren().add(label);
    }
}
