package ui.ribbonbar;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

/**
 * ribbon_ui_main.java
 * -----------------------------------------------------------------------------
 * The Ribbon bar (peach/orange strip). With the in-window title bar removed,
 * this is now the TOPMOST bar inside the window content.
 * Placeholder for future ribbon tabs / command groups.
 * Class name matches the file name exactly.
 */
public class ribbon_ui_main extends HBox {

    public ribbon_ui_main() {
        setAlignment(Pos.CENTER_LEFT);
        setPadding(new Insets(10, 12, 10, 14));
        setPrefHeight(46);
        // Peach background with a blue base line, echoing the wireframe.
        setStyle(
            "-fx-background-color: #F5C99B;" +
            "-fx-border-color: #005A85;" +
            "-fx-border-width: 0 0 2 0;"
        );

        Label label = new Label("Ribbonbar");
        label.setStyle("-fx-text-fill: white; -fx-font-size: 16px; -fx-font-weight: bold;");

        getChildren().add(label);
    }
}
