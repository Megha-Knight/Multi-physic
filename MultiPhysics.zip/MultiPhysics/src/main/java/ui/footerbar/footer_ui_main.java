package ui.footerbar;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

/**
 * footer_ui_main.java
 * -----------------------------------------------------------------------------
 * The Footer bar: the thin status strip pinned to the bottom of the window.
 * Placeholder for status text, coordinates, progress, etc.
 * Class name matches the file name exactly.
 */
public class footer_ui_main extends StackPane {

    public footer_ui_main() {
        setAlignment(Pos.CENTER);
        setPadding(new Insets(8));
        setPrefHeight(34);
        setStyle(
            "-fx-background-color: linear-gradient(to bottom, #eef0f2, #d7dbe0);" +
            "-fx-border-color: #9AA5B1;" +
            "-fx-border-width: 1 0 0 0;"
        );

        Label label = new Label("Footer bar");
        label.setStyle("-fx-text-fill: #1a1a1a; -fx-font-size: 15px;");

        getChildren().add(label);
    }
}
