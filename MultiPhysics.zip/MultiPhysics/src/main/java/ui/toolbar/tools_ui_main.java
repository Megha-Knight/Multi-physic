package ui.toolbar;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

/**
 * tools_ui_main.java
 * -----------------------------------------------------------------------------
 * The Toolbar (white strip under the ribbon). Placeholder for quick-access
 * tool buttons. Text is centred, matching the wireframe.
 * Class name matches the file name exactly.
 */
public class tools_ui_main extends StackPane {

    public tools_ui_main() {
        setAlignment(Pos.CENTER);
        setPadding(new Insets(14));
        setPrefHeight(56);
        setStyle(
            "-fx-background-color: white;" +
            "-fx-border-color: #9AA5B1;" +
            "-fx-border-width: 0 0 1 0;"
        );

        Label label = new Label("Toolbar");
        label.setStyle("-fx-text-fill: #1a1a1a; -fx-font-size: 18px;");

        getChildren().add(label);
    }
}
