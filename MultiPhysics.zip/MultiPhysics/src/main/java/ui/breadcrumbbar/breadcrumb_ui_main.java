package ui.breadcrumbbar;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;

/**
 * breadcrumb_ui_main.java
 * -----------------------------------------------------------------------------
 * The Bread Crumb bar: the grey gradient strip spanning the top of the main
 * content area (to the right of the Navigation bar). Placeholder for the
 * current path / breadcrumb trail. Class name matches the file name exactly.
 */
public class breadcrumb_ui_main extends StackPane {

    public breadcrumb_ui_main() {
        setAlignment(Pos.CENTER);
        setPadding(new Insets(10));
        setPrefHeight(44);
        // Light vertical grey gradient with a thin border, matching the mockup.
        setStyle(
            "-fx-background-color: linear-gradient(to bottom, #f7f7f7, #d9d9d9);" +
            "-fx-border-color: #9AA5B1;" +
            "-fx-border-width: 1;"
        );

        Label label = new Label("Bread Crumb Bar");
        label.setStyle("-fx-text-fill: #1a1a1a; -fx-font-size: 16px;");

        getChildren().add(label);
    }
}
